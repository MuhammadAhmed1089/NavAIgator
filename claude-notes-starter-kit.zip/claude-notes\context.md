# Session & Feature Context Log

Append-only log, newest entries at the top. The point of this file is to let
a future session get oriented by reading a few short entries instead of
re-scanning the whole codebase — keep entries dense, not exhaustive.

This file is scoped to **task/phase completion only** — it records the
final outcome once a task defined in `claude-notes/phases.md` is actually
done, whether completed directly in this session or discovered already
done via a teammate's `git pull`. It is not a running conversation log —
that's what `claude-notes/memory.md` is for. Do not append an entry here
just because a discussion happened or a decision was made; wait until a
phases.md task is actually complete.

`claude-notes/phases.md` itself is fixed and must not be edited to reflect
progress — this file is where progress lives instead.

## How to log

**When you (Claude) complete a task from `claude-notes/phases.md` in this
session:** append an entry using the template below, identifying which
phase/task it closes.

**On every `git pull`:** check the incoming commit messages and diffs
against the open tasks in `claude-notes/phases.md`. If a pulled commit (or
set of commits) completes a task, append an entry here — phase/task
number, what the teammate's commit(s) actually did, and how (derived from
the diff, not just the commit message) — even though you didn't do the
work yourself.

Template:

```
## YYYY-MM-DD — <feature / session title>
**Phase/Task:** <phases.md phase # and task #, if this entry closes one — omit if N/A>
**Goal:** <what this session/feature set out to do>
**Changed:** <files/modules touched, in a phrase each — not a diff>
**Key decisions:** <any non-obvious choice and why, e.g. "used queue over
  cron because retries needed backoff">
**Open items / follow-ups:** <anything left unfinished or intentionally
  deferred>
```

Guidelines:

- One entry per completed task from `phases.md` (whether done directly or
  discovered via a teammate's pull) — not per session, not per commit.
- Skip anything derivable from reading the code itself (directory layout,
  dependency list) — only log things a future session can't easily re-derive.
- If an entry references a mistake that was made and fixed, don't duplicate
  the detail here — just note it happened and point to the dated entry in
  `mistakes.md`.

---

<!-- New entries go below this line, newest first. -->
