# Mistakes Log

Append-only log of mistakes Claude has made on this project, so they are never
repeated. Read this file at the start of every session before writing code.

## How to log a mistake

When you (Claude) catch yourself having made a mistake — introduced a bug,
made a wrong assumption, used an approach that had to be reverted, missed an
edge case that broke something — add an entry using this template, newest
entries at the top:

```
## YYYY-MM-DD — <short title>
**What happened:** <1-2 sentences on the mistake and its symptom>
**Root cause:** <why it happened>
**Fix:** <what resolved it>
**Rule going forward:** <the concrete thing to do differently next time>
```

Keep entries short — a few lines each. If a "rule going forward" turns out to
be a general principle rather than something project-specific, promote it into
`rules.md` instead of leaving it buried here.

---

<!-- New entries go below this line, newest first. -->
