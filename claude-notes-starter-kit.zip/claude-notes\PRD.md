# PRD — <Project Name> Project Requirements

Requirements for this project, derived from <name your source spec
document(s) here — e.g. a proposal doc, a client brief, a design doc>.
This is a rule list to check code/design against — not an implementation
guide.

This file is a standalone reference. It is not auto-updated from session
logs or memory — if a requirement here needs to change, that will be
stated explicitly, or Claude should flag the discrepancy and suggest an
update rather than editing it unprompted.

## Goal

<One or two sentences: what this project does and for whom, stated as
plainly as possible.>

## <Domain> rules

<e.g. "Data rules" / "Input rules" — whatever the project's core input or
domain-object constraints are. Each bullet should be a hard, testable
rule ("must", "never", exact numbers/thresholds), not a description of
how to build it.>

- TBD.

## <Domain> rules

<e.g. "Processing rules" / "Business logic rules" — the core
transformation/behavior constraints.>

- TBD.

## <Domain> rules

<e.g. "Model rules" / "System rules" — architecture-level constraints
that are requirements, not implementation choices (e.g. "must support N
concurrent users," "must use algorithm X," "must be reproducible given
the same input").>

- TBD.

## Evaluation targets

<Concrete, measurable success criteria — the numbers that define "done"
or "good enough." e.g. performance targets, accuracy targets, SLAs.>

- TBD.

## <Other domain> rules

<Add as many of these sections as the project needs — e.g.
"Explainability rules," "Dashboard rules," "Security rules," "Compliance
rules." Delete any that don't apply.>

- TBD.
