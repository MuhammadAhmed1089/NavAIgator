# Software Engineering Principles

A comprehensive reference for Claude to follow when designing, building, and reviewing any software project.

---

## 1. Core Design Principles

### SOLID

- **Single Responsibility Principle (SRP)** — Every class, module, or function should have one reason to change. If it does more than one thing, split it.
- **Open/Closed Principle (OCP)** — Software entities should be open for extension, closed for modification. Add behavior without altering existing code.
- **Liskov Substitution Principle (LSP)** — Subtypes must be substitutable for their base types without altering correctness.
- **Interface Segregation Principle (ISP)** — No client should depend on methods it doesn't use. Prefer small, focused interfaces over fat ones.
- **Dependency Inversion Principle (DIP)** — Depend on abstractions, not concretions. High-level modules should not depend on low-level modules.

### DRY, KISS, YAGNI

- **DRY (Don't Repeat Yourself)** — Every piece of knowledge must have a single, unambiguous representation in the system. Duplication is a maintenance liability.
- **KISS (Keep It Simple, Stupid)** — Prefer the simplest solution that works. Complexity is the enemy of reliability.
- **YAGNI (You Aren't Gonna Need It)** — Don't build features or abstractions until they are actually required. Speculative generality wastes time and creates tech debt.

### Separation of Concerns

- Divide the system into distinct sections, each addressing a separate concern (UI, business logic, data access, etc.).
- Changes in one layer should not cascade unnecessarily into others.

### Law of Demeter (Principle of Least Knowledge)

- A module should only talk to its immediate collaborators. Avoid long chains like `a.getB().getC().doSomething()`.

---

## 2. Code Quality

### Readability First

- Code is read far more often than it is written. Optimize for the next person reading it (which may be you in 6 months).
- Use descriptive, intention-revealing names for variables, functions, and classes.
- Avoid abbreviations unless they are universally understood in the domain.

### Small, Focused Units

- Functions should do one thing and do it well.
- Aim for functions under ~20–30 lines; if longer, consider extracting logic.
- Classes should be cohesive — all methods should relate to the same concept.

### Avoid Magic Numbers & Strings

- Replace raw literals with named constants or enums that communicate intent.

### Consistent Conventions

- Follow the language/framework's idiomatic style (PEP 8 for Python, Airbnb/Standard for JS, etc.).
- Enforce consistency with linters and formatters (ESLint, Prettier, Black, etc.).

### Comments

- Write comments to explain **why**, not **what**. The code itself should communicate what.
- Outdated comments are worse than no comments — keep them accurate or delete them.
- Prefer self-documenting code over excessive commenting.

---

## 3. Architecture & Structure

### Layered Architecture

- Separate concerns into clear layers: Presentation → Business Logic → Data Access.
- Dependencies should flow inward (outer layers depend on inner, not the reverse).

### Modular Design

- Build discrete, independently understandable modules with well-defined public APIs.
- Minimize coupling between modules; maximize cohesion within them.

### Dependency Management

- Prefer dependency injection over hard-coded dependencies to improve testability and flexibility.
- Keep the dependency graph acyclic.

### Configuration over Hardcoding

- Externalize configuration (environment variables, config files). Never hardcode secrets, URLs, or environment-specific values.

### Fail Fast

- Validate inputs and assumptions early. Surface errors as close to their source as possible.
- Use assertions, guard clauses, and input validation at boundaries.

---

## 4. Testing

### Test Pyramid

- Write many **unit tests** (fast, isolated, cheap).
- Write fewer **integration tests** (test component interactions).
- Write even fewer **end-to-end tests** (test full flows; slow and brittle if over-relied upon).

### Test Behavior, Not Implementation

- Tests should verify observable outcomes, not internal details. This allows refactoring without breaking tests.

### AAA Pattern

- Structure tests as: **Arrange** (set up), **Act** (execute), **Assert** (verify).

### Test Coverage

- Aim for meaningful coverage of critical paths, edge cases, and error conditions — not just a coverage percentage.
- 100% coverage with poor assertions is worse than 70% coverage with strong assertions.

### Tests as Documentation

- Test names should read as specifications: `should_return_empty_list_when_no_items_match`.

---

## 5. Error Handling

- **Never silently swallow errors.** Log or propagate every exception.
- Distinguish between recoverable errors (return error values / Result types) and unrecoverable ones (crash loudly).
- Provide meaningful error messages that help diagnose the problem.
- Use typed/domain-specific exceptions rather than generic ones.
- Handle errors at the appropriate layer — don't let data-layer exceptions leak into the UI.

---

## 6. Performance

- **Measure before optimizing.** Profile first; don't guess where bottlenecks are.
- Prefer algorithmic improvements (O(n) → O(log n)) over micro-optimizations.
- Cache expensive computations, but invalidate caches correctly.
- Be mindful of N+1 query problems in database access.
- Lazy-load resources when eagerly loading is unnecessary.
- Premature optimization is the root of much evil — optimize when there is a measured need.

---

## 7. Security

- **Principle of Least Privilege** — grant only the permissions actually needed.
- **Never trust user input.** Validate and sanitize all external data.
- Parameterize all database queries to prevent SQL injection.
- Encode output correctly to prevent XSS.
- Store passwords using strong adaptive hashing (bcrypt, Argon2) — never plaintext.
- Keep secrets out of source control (use environment variables or secret managers).
- Keep dependencies up to date; audit for known vulnerabilities.
- Use HTTPS everywhere; never transmit sensitive data over plain HTTP.
- Apply defense in depth — multiple layers of security, not a single perimeter.

---

## 8. Version Control

- **Commit small and often.** Each commit should represent one logical change.
- Write clear commit messages: subject line summarizing _what_, body explaining _why_.
- Use feature branches; keep `main`/`master` always deployable.
- Review code before merging (pull requests / code review).
- Never commit secrets, credentials, or large binary files.
- Tag releases meaningfully (semantic versioning: `MAJOR.MINOR.PATCH`).

---

## 9. Documentation

- Every project should have a `README.md` covering: purpose, prerequisites, setup, usage, and contribution guide.
- Document public APIs (functions, classes, endpoints) with clear descriptions, parameters, and return values.
- Keep documentation in sync with the code — stale docs are harmful.
- Architecture Decision Records (ADRs) are valuable for capturing _why_ major decisions were made.

---

## 10. Refactoring

- Refactor continuously — don't let tech debt accumulate until it's unmanageable.
- Always have tests in place before refactoring (tests are your safety net).
- Change structure in one commit, behavior in another — never both at once.
- Follow the boy scout rule: **leave the code cleaner than you found it.**

---

## 11. Concurrency & Reliability

- Prefer immutability where possible — it eliminates whole classes of concurrency bugs.
- Make operations idempotent where practical (especially in distributed systems).
- Design for failure: assume networks fail, services go down, disks fill up.
- Use timeouts, retries with exponential backoff, and circuit breakers for external calls.
- Log enough to debug production issues without exposing sensitive data.

---

## 12. API Design

- Be consistent — use the same naming conventions, error formats, and pagination patterns throughout.
- Design APIs to be intuitive: principle of least surprise.
- Version your APIs from day one (`/v1/`, `Accept: application/vnd.api+json; version=2`).
- Use HTTP semantics correctly (GET is safe and idempotent, POST is not, etc.).
- Return meaningful status codes and structured error responses.
- Document with OpenAPI/Swagger or equivalent.

---

## 13. Observability

- **Logging** — structured logs with consistent fields (timestamp, level, correlation ID).
- **Metrics** — instrument key business and system metrics (latency, error rate, throughput).
- **Tracing** — distributed traces for multi-service flows.
- An unmonitored system in production is a ticking time bomb.

---

## 14. Deployment & DevOps

- Automate builds, tests, and deployments (CI/CD pipelines).
- Every merge to main should trigger automated testing.
- Infrastructure as Code — version control your infrastructure (Terraform, Pulumi, CloudFormation).
- Use feature flags to decouple deployment from release.
- Blue/green or canary deployments reduce risk of bad releases.
- Have a tested rollback plan for every deployment.

---

## Quick Reference Checklist

Before submitting any code, verify:

- [ ] Does each function/class have a single, clear responsibility?
- [ ] Is there any duplicated logic that should be extracted?
- [ ] Are all inputs validated and errors handled?
- [ ] Are there unit tests covering the happy path and edge cases?
- [ ] Are there any hardcoded secrets, URLs, or magic values?
- [ ] Are names descriptive and consistent with the codebase?
- [ ] Is the code as simple as it can be while still meeting requirements?
- [ ] Is the public API documented?
- [ ] Would a teammate understand this code without asking you questions?

---

_These principles are guidelines, not rigid laws. Context matters. Use good judgment, and when in doubt, optimize for clarity and maintainability._
