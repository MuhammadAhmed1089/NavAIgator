# Rules

Standing rules for Claude Code on this project. These override convenience or
speed whenever they conflict.

## Git & commits

- **Never commit using Claude.** Claude may `git add`, `git diff`, `git status`,
  and prepare a suggested commit message — but the actual `git commit` and
  `git push` are always run by the person, from their own GitHub-authenticated
  environment.
- Do not create branches, open PRs, or merge anything on the user's behalf
  without being asked in that session.

- **Claude setup files are local-only.** `CLAUDE.md`, `claude-notes/` and
  `.claude/` must always be listed in `.gitignore` and never be tracked,
  staged, committed, or pushed. Never `git add -f` them. If they show up as
  tracked or untracked-and-unignored in `git status`, fix `.gitignore` (and
  `git rm --cached` if already tracked, asking first) before anything else.

## Code writing (ponytail)

- Always invoke the `ponytail:ponytail` skill before writing, editing,
  refactoring, or reviewing any code (default intensity: full). It is the
  default for all code work, enforced by hooks in `.claude/settings.json`
  (SessionStart and UserPromptSubmit), so it applies even if a prompt never
  mentions it. Skip it only for non-coding work.
- Ponytail's minimal bias must not drop anything the spec or
  `claude-notes/PRD.md` requires; the PRD wins over brevity.

## Logging discipline

- Follow the `context.md` logging rule: append a dated entry to
  `claude-notes/context.md` whenever a task defined in `claude-notes/phases.md`
  is completed — whether done directly in this session or discovered already
  done via a teammate's `git pull`. This is how future sessions avoid
  re-deriving context from scratch (and burning tokens re-reading the whole
  codebase).
- Follow the `memory.md` logging rule: at the start of every session, create a
  new dated section in `claude-notes/memory.md`, and update it throughout the
  session with meaningful decisions, discoveries, and discussion — this is the
  running conversation log, distinct from `context.md`'s task-completion scope.
- If Claude makes a mistake during a session — a bug it introduced, a bad
  assumption, a wrong approach that had to be reverted — log it in
  `claude-notes/mistakes.md` before the session ends, so it is not repeated.

## Engineering standard

- All code Claude writes or reviews should follow `claude-notes/se-principles.md`.
  When a suggestion in that file would conflict with an explicit instruction
  from the user in the moment, the user's instruction wins — but Claude should
  say so out loud rather than silently deviating.

## Scope

- Ask before touching CI/CD config, infra-as-code, or anything under
  `.github/workflows/`.
- Ask before installing new dependencies; prefer what's already in the
  lockfile/manifest.
