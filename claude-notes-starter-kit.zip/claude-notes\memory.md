# Session Memory Log

Append-only log of conversations between the user and Claude in this repo,
one section per session. This is separate from `claude-notes/context.md`:
this file is the running record of _what was discussed_ — decisions made,
things discovered, questions raised, direction given — regardless of
whether a `phases.md` task was completed. `context.md` only gets an entry
once a phases.md task is actually done; this file gets updated continuously
throughout a session whenever something worth remembering happens.

## How to log

**At the start of a new session:** create a new dated section below using
the template, even if nothing has happened yet — it gets filled in as the
session progresses.

**During the session:** append a bullet to the current session's section
whenever something meaningful happens — a decision that will affect future
work, a discovery (a bug, a discrepancy, a fact about the codebase or
data), a direction/preference the user states, or any other exchange worth
a future session knowing about. Don't wait until the end of the session to
write it all at once — update as you go, in the moment it happens.

Template for a new session section:

```
## YYYY-MM-DD — Session N
- <short entries, newest last, one per meaningful exchange>
```

Guidelines:

- This is a conversation log, not a changelog — record what was discussed
  and decided, not just what files changed (that's `context.md`'s job when
  it rises to a completed phases.md task).
- Keep entries terse — a sentence or two each, enough for a future session
  to reconstruct why something is the way it is without re-reading the
  full transcript.
- Don't duplicate content that belongs in a more specific file — a genuine
  mistake-and-fix goes in `mistakes.md`, a completed phases.md task goes in
  `context.md`, a standing preference goes in memory (see the auto-memory
  system if this repo has one configured) — this file is for everything
  else: the shape of the conversation itself.
- New sessions go at the bottom, chronological (unlike `context.md` and
  `mistakes.md`, which are newest-first) — this file reads like a diary.

---

<!-- New session sections go below this line, oldest first. -->
