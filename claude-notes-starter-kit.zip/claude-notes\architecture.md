# Architecture — Repo Structure & Tech Stack

This file must be kept current: update it whenever a file is created or
removed, and after every `git pull` if it introduces files/directories not
already reflected here. Do not let this drift — it is read at the start of
every session as the map of what exists.

## Tech stack

- **Language / runtime:** TBD
- **Database:** TBD
- **Core libraries:** TBD (list by purpose — data, models, testing, etc.)
- **Testing:** TBD
- **Env management:** TBD

## Repo structure

```
<project-name>/
├── CLAUDE.md
└── claude-notes/
    ├── rules.md
    ├── mistakes.md
    ├── context.md
    ├── se-principles.md
    ├── PRD.md
    ├── architecture.md              # this file
    ├── phases.md
    ├── design.md
    └── memory.md
```

<Fill in the rest of the tree as the project's real structure takes
shape — one line per file/directory with a short purpose comment, not a
full docstring.>

## Maintenance rule

- After creating, deleting, or renaming any file/directory in this repo —
  whether done manually (by Claude or the user) or brought in via a
  `git pull` — update the tree above in that same session, before moving
  on to other work. A rename is both a removal and an addition; update
  both sides of it in the tree, don't leave the old name lingering.
- After every `git pull`, diff the new state against this file even if no
  other work is planned that session; if files/directories appeared, were
  removed, or were renamed and aren't reflected here, update this file
  before continuing.
- Keep entries as one-line purpose annotations, not full docstrings —
  this is a map, not documentation.
