# Project Memory

This file is auto-loaded by Claude Code (CLI and VS Code extension) at the
start of every session. It pulls in the working files below via @imports —
do not delete these lines.

@claude-notes/rules.md
@claude-notes/mistakes.md
@claude-notes/context.md
@claude-notes/se-principles.md
@claude-notes/PRD.md
@claude-notes/architecture.md
@claude-notes/phases.md
@claude-notes/design.md
@claude-notes/memory.md

## Session protocol

1. On start: read `claude-notes/rules.md` first, then `claude-notes/mistakes.md`
   (past mistakes — do not repeat them), then `claude-notes/PRD.md` (project
   requirements — check code and design decisions against these), then
   `claude-notes/architecture.md` (repo file structure and tech stack), then
   `claude-notes/phases.md` (what phase/task the project is on), then
   `claude-notes/design.md` (frontend design requirements), then the latest
   entries in `claude-notes/context.md` (completed phases.md tasks) and
   `claude-notes/memory.md` (session conversation history) for where the
   project and the conversation left off. Create a new dated section in
   `memory.md` for this session now, per the template inside that file.
2. During work: follow `claude-notes/se-principles.md` for all code you write
   or review, and `claude-notes/PRD.md` for what the project must actually do.
   Log meaningful decisions, discoveries, and discussion points to the
   current session's section in `claude-notes/memory.md` as they happen,
   not just at the end.
3. On completing a task defined in `claude-notes/phases.md` (whether done
   directly or discovered already done via a teammate's `git pull`): append
   an entry to `claude-notes/context.md` (see template inside that file).
   `claude-notes/context.md` is scoped to task/phase completions only —
   general discussion goes in `memory.md`, not here. If you made and caught
   a mistake worth remembering, append it to `claude-notes/mistakes.md`.
4. Keep `claude-notes/architecture.md` in sync with the real repo: update it
   immediately after creating, deleting, or renaming any file/directory
   (manually or via `git pull`), and check it against the repo state after
   every `git pull` regardless of what else that pull touched.
5. On every `git pull`: check the incoming commit messages and diffs
   against the open tasks in `claude-notes/phases.md`. If a pulled commit
   completes a task, log it to `claude-notes/context.md` per its "on pull"
   instructions. Never edit `claude-notes/phases.md` itself to reflect
   progress — it is fixed and only changes on explicit instruction.
6. Writing code: always invoke the `ponytail:ponytail` skill (Skill tool)
   before writing, editing, refactoring, or reviewing any code. This is the
   default for all code work, whether or not the prompt mentions it, and is
   backed by the hooks in `.claude/settings.json`. Skip it for non-code work
   (notes, docs, Q&A).
7. Never run `git commit` or `git push`. Stage changes if asked, but leave
   committing to the user's own GitHub-authenticated environment — see
   `claude-notes/rules.md`.
