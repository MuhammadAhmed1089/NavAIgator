# Phases — <N>-Week Implementation Roadmap

Condensed from <name your source project-plan document(s) here>. Team:
<N> owners (<A/B/C or names>), one phase per week, each phase has one
hard prerequisite (the previous phase's deliverable) and closes with a
defined deliverable. Cross-checked against `claude-notes/PRD.md` — phase/
task structure, ownership, and week numbering follow the source plan
as-is.

Once filled in, this file is fixed and should not be edited to reflect
ongoing progress — task/phase completions are logged in
`claude-notes/context.md` instead (per its own rules, including checking
teammates' `git pull`s against these tasks). Only edit this file directly
on explicit instruction (e.g. the plan itself changed).

## Timeline

| Wk  | Phase | Focus   | Deliverable   |
| --- | ----- | ------- | ------------- |
| 1   | 1     | <Focus> | <Deliverable> |
| 2   | 2     | <Focus> | <Deliverable> |
| ... | ...   | ...     | ...           |

## Phase 1 — <Focus> (Week 1)

Prerequisite: none.

- **Task 1 (<Owner>):** <description>.
- **Task 2 (<Owner>):** <description>.
- **Task 3 (<Owner>):** <description>.

## Phase 2 — <Focus> (Week 2)

Prerequisite: <previous phase's deliverable>.

- **Task 1 (<Owner>):** <description>.
- **Task 2 (<Owner>):** <description>.
- **Task 3 (<Owner>):** <description>.

<Repeat one "## Phase N — <Focus> (Week N)" section per phase in the
timeline table above, with a Prerequisite line and Task bullets for each
owner, until every phase in the project plan is represented.>
